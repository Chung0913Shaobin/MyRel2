# =============================================
# 履歷分析系統
# 功能：使用多個 AI 模型（DeepSeek、Gemini、OpenAI）分析履歷
# 提供技能分類、改進建議和評分
# =============================================

# 導入必要的庫
from flask import Flask, request, render_template, jsonify, send_from_directory  # Flask 網頁框架
import requests  # 發送 HTTP 請求
import os  # 文件系統操作
import logging  # 日誌記錄
from docx import Document  # 讀取 Word 文件
from PyPDF2 import PdfReader  # 讀取 PDF 文件
from werkzeug.utils import secure_filename  # 安全處理文件名
import google.generativeai as genai  # Google Gemini API
import json  # JSON 處理
import re  # 正則表達式
from datetime import datetime
import matplotlib.pyplot as plt
import numpy as np

# =============================================
# 初始化配置
# =============================================

# 創建 Flask 應用
app = Flask(__name__, 
    template_folder='.',  # 設置模板目錄為當前目錄
    static_folder='.'     # 設置靜態文件目錄為當前目錄
)

# 添加檔案上傳相關的配置
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

# API 密鑰配置
DEEPSEEK_API_KEY = "sk-c17852df776c481eaf9c7d7e7951b498"
GEMINI_API_KEY = "AIzaSyB2AsIs5YNb5wF_wpZ2xVySwv3mZ5pRF5s"
OPENAI_API_KEY = "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"

# API 端點配置
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent"

# 配置 Gemini API
genai.configure(api_key=GEMINI_API_KEY)

# 創建上傳目錄（如果不存在）
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# 配置日誌記錄
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

# =============================================
# 核心功能函數
# =============================================

def extract_text(file_path, extension):
    """
    從上傳的文件中提取文本內容
    
    參數:
        file_path (str): 文件路徑
        extension (str): 文件擴展名（pdf 或 docx）
    
    返回:
        str: 提取的文本內容
    """
    try:
        if not os.path.exists(file_path):
            logging.error(f"檔案不存在: {file_path}")
            return None
            
        if extension == 'pdf':
            # 讀取 PDF 文件
            reader = PdfReader(file_path)
            if not reader.pages:
                logging.error("PDF 檔案沒有頁面")
                return None
            text = ""
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
            return text.strip() if text else None
            
        elif extension == 'docx':
            # 讀取 Word 文件
            doc = Document(file_path)
            if not doc.paragraphs:
                logging.error("Word 檔案沒有內容")
                return None
            text = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
            return text.strip() if text else None
            
        else:
            logging.error(f"不支援的檔案格式: {extension}")
            return None
            
    except Exception as e:
        logging.error(f"提取檔案內容失敗：{str(e)}")
        return None

def ask_deepseek(prompt):
    """
    調用 DeepSeek API 進行文本分析
    
    參數:
        prompt (str): 要發送給 API 的提示文本
    
    返回:
        str: API 的回應文本
    """
    # 設置請求頭
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # 設置請求數據
    payload = {
        "model": "deepseek-chat",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 2048
    }

    try:
        # 發送 POST 請求
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=payload)
        if response.status_code != 200:
            logging.error(f"DeepSeek API 回應錯誤：{response.status_code} - {response.text}")
            return "DeepSeek API 回應錯誤，請稍後再試。"

        # 解析回應
        data = response.json()

        if "choices" not in data or not data["choices"]:
            logging.error(f"DeepSeek 回傳格式錯誤：{data}")
            return "DeepSeek API 回傳內容異常。"

        return data["choices"][0]["message"]["content"].strip()

    except Exception as e:
        logging.error(f"與 DeepSeek 通訊時發生錯誤：{e}")
        return "與 DeepSeek 通訊失敗，請稍後再試。"

def ask_openai(prompt):
    """
    調用 OpenAI API 進行文本分析
    
    參數:
        prompt (str): 要發送給 API 的提示文本
    
    返回:
        str: API 的回應文本
    """
    # 設置請求頭
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # 設置請求數據
    payload = {
        "model": "gpt-3.5-turbo",  # 改為 gpt-3.5-turbo
        "messages": [{"role": "user", "content": prompt}]
    }

    try:
        # 發送 POST 請求
        response = requests.post(OPENAI_API_URL, headers=headers, json=payload)
        if response.status_code != 200:
            logging.error(f"OpenAI API 回應錯誤：{response.status_code} - {response.text}")
            return "OpenAI API 回應錯誤，請稍後再試。"

        # 解析回應
        data = response.json()

        if "choices" not in data or not data["choices"]:
            logging.error(f"OpenAI API 回傳格式錯誤：{data}")
            return "OpenAI API 回傳內容異常。"

        return data["choices"][0]["message"]["content"].strip()
    
    except Exception as e:
        logging.error(f"與 OpenAI 通訊時發生錯誤：{e}")
        return "與 OpenAI 通訊失敗，請稍後再試。"

def ask_gemini(prompt):
    """
    調用 Gemini API 進行文本分析
    
    參數:
        prompt (str): 要發送給 API 的提示文本
    
    返回:
        str: API 的回應文本
    """
    try:
        # 創建模型實例並生成內容
        model = genai.GenerativeModel("gemini-2.0-flash")
        response = model.generate_content(prompt)

        if not response.text:
            logging.error(f"Gemini 回傳內容為空或異常：{response}")
            return "Gemini API 回傳內容異常。"

        return response.text.strip()

    except Exception as e:
        logging.error(f"與 Gemini 通訊時發生錯誤：{e}")
        return "與 Gemini 通訊失敗，請稍後再試。"

def clean_ai_output(text):
    """
    清理 AI 輸出的文本，移除不必要的標記和格式
    
    參數:
        text (str): 原始文本
    
    返回:
        str: 清理後的文本
    """
    text = re.sub(r"#+\s*", "", text)  # 移除標題標記
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)  # 移除粗體標記
    text = re.sub(r"-{2,}", "", text)  # 移除分隔線
    text = re.sub(r"^[-•]\s*", "", text, flags=re.MULTILINE)  # 移除列表標記
    text = re.sub(r"\n{2,}", "\n", text)  # 移除多餘的空行
    return text.strip()

def extract_explanation(text, category):
    """從 AI 回應中提取各項評分說明"""
    try:
        patterns = {
            'skills': r'技能匹配度[^。]*。',
            'experience': r'工作經驗與成就[^。]*。',
            'structure': r'履歷結構與可讀性[^。]*。',
            'personality': r'個人特色[^。]*。',
            'data_expression': r'數據化表達能力[^。]*。'
        }
        
        match = re.search(patterns[category], text)
        if match:
            return match.group(0).split('：')[-1].strip()
        return "未提供評估說明"
        
    except Exception as e:
        logging.error(f"提取評分說明時發生錯誤: {str(e)}")
        return "未提供評估說明"

def analyze_resume(content):
    if not content:
        raise ValueError("履歷內容為空，無法進行分析")
    try:
        # 構建分析提示
        prompt = f"""
        請分析以下履歷內容，並根據以下標準進行評分（每項20分，總分100分）：
        1. 技能匹配度 - 評估專業技能與目標職位的匹配程度
        2. 工作經驗與成就 - 評估工作經驗的相關性和成就展示
        3. 履歷結構與可讀性 - 評估履歷的組織結構和表達清晰度
        4. 個人特色 - 評估個人特質和價值主張的展現
        5. 數據化表達能力 - 評估成果的量化表達
        
        履歷內容：
        {content}
        
        請提供詳細的評分和改進建議。
        """
        
        # 調用 AI API 並獲取結果
        deepseek_result = ask_deepseek(prompt)
        deepseek_scores = extract_scores(deepseek_result)
        
        openai_result = ask_openai(prompt)
        openai_scores = extract_scores(openai_result)
        
        gemini_result = ask_gemini(prompt)
        gemini_scores = extract_scores(gemini_result)
        
        # 清理 AI 輸出
        cleaned_result = clean_ai_output(deepseek_result)
        
        # 計算平均分數用於五角圖
        avg_scores = {
            'skills': round((deepseek_scores['skills'] + openai_scores['skills'] + gemini_scores['skills']) / 3, 1),
            'experience': round((deepseek_scores['experience'] + openai_scores['experience'] + gemini_scores['experience']) / 3, 1),
            'structure': round((deepseek_scores['structure'] + openai_scores['structure'] + gemini_scores['structure']) / 3, 1),
            'personality': round((deepseek_scores['personality'] + openai_scores['personality'] + gemini_scores['personality']) / 3, 1),
            'data_expression': round((deepseek_scores['data_expression'] + openai_scores['data_expression'] + gemini_scores['data_expression']) / 3, 1)
        }
        
        # 準備圖表數據
        chart_data = {
            'labels': ['技能匹配度', '工作經驗與成就', '履歷結構與可讀性', '個人特色', '數據化表達能力'],
            'values': [
                deepseek_scores['skills'],
                deepseek_scores['experience'],
                deepseek_scores['structure'],
                deepseek_scores['personality'],
                deepseek_scores['data_expression']
            ]
        }
        
        # 修改返回結構，加入雷達圖數據格式
        return {
            'status': 'success',
            'score_data': {
                'deepseek': deepseek_scores['total'],
                'openai': openai_scores['total'],
                'gemini': gemini_scores['total'],
                'radar_chart_data': {
                    'labels': ['技能匹配度', '工作經驗與成就', '履歷結構與可讀性', '個人特色', '數據化表達能力'],
                    'datasets': [{
                        'label': '履歷評估結果',
                        'data': [
                            round(deepseek_scores['skills'] / 4),  # 轉換為0-5分
                            round(deepseek_scores['experience'] / 4),
                            round(deepseek_scores['structure'] / 4),
                            round(deepseek_scores['personality'] / 4),
                            round(deepseek_scores['data_expression'] / 4)
                        ],
                        'backgroundColor': 'rgba(75, 192, 192, 0.2)',
                        'borderColor': 'rgba(75, 192, 192, 1)',
                        'pointBackgroundColor': 'rgba(75, 192, 192, 1)'
                    }]
                },
                'score_explanation': {
                    '技能匹配度': extract_explanation(deepseek_result, 'skills'),
                    '工作經驗與成就': extract_explanation(deepseek_result, 'experience'),
                    '履歷結構與可讀性': extract_explanation(deepseek_result, 'structure'),
                    '個人特色': extract_explanation(deepseek_result, 'personality'),
                    '數據化表達能力': extract_explanation(deepseek_result, 'data_expression')
                }
            },
            'analysis_text': cleaned_result
        }
        
    except Exception as e:
        logging.error(f"分析過程發生錯誤: {str(e)}")
        raise

def extract_scores(text):
    """從 AI 回應中提取各項評分"""
    try:
        import re
        scores = {
            'skills': 0,
            'experience': 0,
            'structure': 0,
            'personality': 0,
            'data_expression': 0,  # 新增的數據化表達能力
            'total': 0
        }
        
        # 提取各項分數
        skills_match = re.search(r'技能匹配度 - 評分：(\d+)/20', text)
        experience_match = re.search(r'工作經驗與成就 - 評分：(\d+)/20', text)
        structure_match = re.search(r'履歷結構與可讀性 - 評分：(\d+)/20', text)
        personality_match = re.search(r'個人特色 - 評分：(\d+)/20', text)
        data_expression_match = re.search(r'數據化表達能力 - 評分：(\d+)/20', text)  # 新增的匹配
        total_match = re.search(r'總分：(\d+)/100', text)
        
        if skills_match:
            scores['skills'] = min(max(int(skills_match.group(1)), 0), 20)
        if experience_match:
            scores['experience'] = min(max(int(experience_match.group(1)), 0), 20)
        if structure_match:
            scores['structure'] = min(max(int(structure_match.group(1)), 0), 20)
        if personality_match:
            scores['personality'] = min(max(int(personality_match.group(1)), 0), 20)
        if data_expression_match:  # 新增的分數提取
            scores['data_expression'] = min(max(int(data_expression_match.group(1)), 0), 20)
        if total_match:
            scores['total'] = min(max(int(total_match.group(1)), 0), 100)
        
        return scores
    except Exception as e:
        print(f"Error: {e}")  # 打印錯誤信息以便調試
        return {
            'skills': 0,
            'experience': 0,
            'structure': 0,
            'personality': 0,
            'data_expression': 0,  # 確保返回的字典中包含新指標
            'total': 0
        }

def extract_recommended_jobs(text):
    """從 AI 回應中提取推薦職位"""
    try:
        import re
        jobs = re.findall(r'【推薦職位】\s*\d+\.\s*(.*?)(?=\d+\.|$)', text, re.DOTALL)
        return [job.strip() for job in jobs[:3]] or ['未提供推薦職位', '未提供推薦職位', '未提供推薦職位']
    except:
        return ['未提供推薦職位', '未提供推薦職位', '未提供推薦職位']

def plot_radar_chart(data, labels):
    if len(data) != len(labels):
        raise ValueError("數據和標籤的長度必須相同")

    # 計算每個角度
    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
    
    # 繞回到起點
    data = np.concatenate((data,[data[0]]))
    angles += angles[:1]

    # 繪製雷達圖
    fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
    ax.fill(angles, data, color='blue', alpha=0.25)
    ax.plot(angles, data, color='blue', linewidth=2)

    # 添加標籤
    ax.set_yticklabels([])
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels)

    plt.title("履歷評分五角圖")
    plt.show()

def analyze_data(text):
    scores = extract_scores(text)
    # 將分數轉換為列表以便繪製
    score_values = [scores['skills'], scores['experience'], scores['structure'], scores['personality'], scores['data_expression']]
    labels = ['技能匹配度', '工作經驗與成就', '履歷結構與可讀性', '個人特色', '數據化表達能力']
    
    # 確保結果和標籤的長度一致
    if len(score_values) != len(labels):
        raise ValueError("分析結果和標籤數量不匹配")
    
    # 輸出分析結果
    for label, score in zip(labels, score_values):
        print(f"{label}: {score}")

    plot_radar_chart(score_values, labels)

# =============================================
# 路由處理函數
# =============================================

# 基本路由
@app.route("/")
def index():
    return render_template('履歷分析.html')

# 主要頁面路由
@app.route("/履歷分析.html")
def resume_analysis():
    return render_template('履歷分析.html')

@app.route("/分析結果.html")
def analysis_result():
    return render_template('分析結果.html')

@app.route("/市場趨勢.html")
def market_trend():
    return render_template('市場趨勢.html')

@app.route("/目錄.html")
def directory():
    return render_template('目錄.html')

@app.route("/企業匹配.html")
def company_match():
    return render_template('企業匹配.html')

@app.route("/技能檢測.html")
def skill_test():
    return render_template('技能檢測.html')

@app.route("/個人檔案.html")
def profile():
    return render_template('個人檔案.html')

@app.route("/履歷優化.html")
def resume_optimization():
    return render_template('履歷優化.html')

@app.route("/學習資源.html")
def learning_resources():
    return render_template('學習資源.html')

@app.route("/職涯規劃.html")
def career_planning():
    return render_template('職涯規劃.html')

# 檢查檔案格式
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 確保上傳目錄存在
def ensure_upload_folder():
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)

# 搜尋相關的資料
INDUSTRY_CATEGORIES = [
    '科技業', '金融業', '製造業', '服務業', '教育業',
    '醫療業', '建築業', '零售業', '餐飲業', '其他'
]

LOCATIONS = [
    '台北市', '新北市', '桃園市', '台中市', '台南市',
    '高雄市', '基隆市', '新竹市', '嘉義市', '其他'
]

COMPANY_SIZES = [
    '1-50人', '51-200人', '201-500人', '501-1000人', '1000人以上'
]

SKILL_CATEGORIES = [
    '程式開發', '設計', '行銷', '管理', '語言',
    '數據分析', '專案管理', '溝通協調', '其他'
]

# 添加搜尋路由
@app.route("/search", methods=["POST"])
def search():
    try:
        data = request.get_json()
        keyword = data.get('keyword', '')
        industry = data.get('industry', '')
        location = data.get('location', '')
        company_size = data.get('company_size', '')
        skill_category = data.get('skill_category', '')
        
        # 這裡可以添加搜尋邏輯
        # 目前先返回示例數據
        results = {
            'matches': [
                {
                    'title': '軟體工程師',
                    'company': '示例公司',
                    'location': '台北市',
                    'industry': '科技業',
                    'skills': ['Python', 'JavaScript', 'SQL']
                }
            ]
        }
        
        return jsonify(results)
        
    except Exception as e:
        logging.error(f"Search error: {str(e)}")
        return jsonify({'error': '搜尋過程中發生錯誤'}), 500

# 修改檔案上傳路由
@app.route("/upload", methods=["POST"])
def upload_file():
    try:
        # 檢查是否有檔案上傳
        if 'file' not in request.files and 'content' not in request.form:
            logging.error("沒有檔案或內容上傳")
            return jsonify({'error': '請上傳檔案或輸入履歷內容'}), 400

        # 處理檔案上傳
        if 'file' in request.files:
            file = request.files['file']
            if file.filename == '':
                logging.error("沒有選擇檔案")
                return jsonify({'error': '請選擇要上傳的檔案'}), 400
            
            if not allowed_file(file.filename):
                logging.error(f"不支援的檔案格式: {file.filename}")
                return jsonify({'error': '只支援 PDF、DOC 和 DOCX 格式'}), 400
            
            try:
                # 確保上傳目錄存在
                ensure_upload_folder()
                
                # 安全處理檔案名稱
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                
                # 儲存檔案
                file.save(filepath)
                logging.info(f"檔案已成功上傳: {filepath}")
                
                # 讀取檔案內容
                extension = filename.rsplit('.', 1)[1].lower()
                content = extract_text(filepath, extension)
                
                if not content:
                    logging.error("無法讀取檔案內容")
                    return jsonify({'error': '無法讀取檔案內容，請確認檔案格式是否正確'}), 400
                    
            except Exception as e:
                logging.error(f"檔案處理錯誤: {str(e)}")
                return jsonify({'error': f'檔案處理失敗: {str(e)}'}), 500
                
        else:
            # 處理文字內容
            content = request.form.get('content', '').strip()
            if not content:
                logging.error("沒有輸入履歷內容")
                return jsonify({'error': '請輸入履歷內容'}), 400

        try:
            # 調用 AI 分析
            analysis_results = analyze_resume(content)
            
            # 返回分析結果
            return jsonify({
                'status': 'success',
                'score_data': analysis_results['score_data'],
                'analysis_text': analysis_results['analysis_text']
            })
            
        except Exception as e:
            logging.error(f"分析過程發生錯誤: {str(e)}")
            return jsonify({'error': f'分析過程發生錯誤: {str(e)}'}), 500

    except Exception as e:
        logging.error(f"上傳過程發生錯誤: {str(e)}")
        return jsonify({'error': f'上傳過程發生錯誤: {str(e)}'}), 500

# 添加獲取選項數據的路由
@app.route("/api/options", methods=["GET"])
def get_options():
    return jsonify({
        'industries': INDUSTRY_CATEGORIES,
        'locations': LOCATIONS,
        'company_sizes': COMPANY_SIZES,
        'skill_categories': SKILL_CATEGORIES
    })

# =============================================
# 程序入口
# =============================================
if __name__ == "__main__":
    app.run(debug=True)


