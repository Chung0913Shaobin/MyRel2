# services/text_utils.py

import re
import json
import logging

def clean_ai_output(text):
    """清除 markdown 標記與多餘空格、符號"""
    text = re.sub(r"#+\s*", "", text)  # 移除標題符號 #
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)  # 去除粗體 **
    text = re.sub(r"-{2,}", "", text)  # 去除多個 -
    text = re.sub(r"^[-•]\s*", "", text, flags=re.MULTILINE)  # 去除條列符號
    text = re.sub(r"\n{2,}", "\n", text)  # 移除過多空行
    return text.strip()


def extract_json_from_text(text):
    """從 AI 回傳中萃取出 JSON 格式的評分"""
    default_scores = {
        "技能匹配度": 0,
        "工作經驗與成就": 0,
        "履歷結構與可讀性": 0,
        "個人特色": 0,
        "學歷與成績": 0,
        "證照與專業認證": 0,
        "專案實作能力": 0,
        "程式設計能力": 0
    }

    try:
        if not text.strip():
            return default_scores

        # 嘗試定位 JSON 區塊
        json_start = text.find("{")
        json_end = text.rfind("}") + 1
        raw = text[json_start:json_end]

        # 預處理：冒號、鍵名稱、單引號等修正
        raw = raw.replace("：", ":")
        raw = re.sub(r'([{\[,])\s*([\u4e00-\u9fa5\w]+)\s*:', r'\1 "\2":', raw)
        raw = re.sub(r":\s*'([^']*)'", r': "\1"', raw)
        raw = re.sub(r"//.*", "", raw)
        raw = re.sub(r",\s*}", "}", raw)
        raw = re.sub(r",\s*]", "]", raw)

        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            return parsed
        else:
            return default_scores

    except Exception as e:
        logging.error(f"❌ JSON 擷取失敗：{e}")
        return default_scores


def average_scores(*score_dicts):
    """計算多個評分 dict 的平均值"""
    keys = [
        "技能匹配度", "工作經驗與成就", "履歷結構與可讀性", "個人特色",
        "學歷與成績", "證照與專業認證", "專案實作能力", "程式設計能力"
    ]
    valid_dicts = [sd for sd in score_dicts if any(sd.get(k, 0) > 0 for k in keys)]

    if not valid_dicts:
        return {k: 0 for k in keys + ["總分"]}

    avg = {}
    for key in keys:
        total = sum(sd.get(key, 0) for sd in valid_dicts)
        avg[key] = round(total / len(valid_dicts))
    avg["總分"] = round(sum(avg.values()) / len(keys))
    return avg
