import requests
import logging
import google.generativeai as genai
from config import OPENAI_API_KEY, DEEPSEEK_API_KEY, GEMINI_API_KEY
from config import OPENAI_API_URL, DEEPSEEK_API_URL

genai.configure(api_key=GEMINI_API_KEY)

def ask_openai(prompt):
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "gpt-4",
        "messages": [{"role": "user", "content": prompt}]
    }

    try:
        response = requests.post(OPENAI_API_URL, headers=headers, json=payload)
        data = response.json()

        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logging.error(f"OpenAI 錯誤：{e}")
        return ""

def ask_deepseek(prompt):
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "deepseek-chat",
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 2048
    }

    try:
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=payload)
        data = response.json()

        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logging.error(f"DeepSeek 錯誤：{e}")
        return ""

def ask_gemini(prompt):
    try:
        model = genai.GenerativeModel("gemini-2.0-flash")
        response = model.generate_content(prompt)

        return response.text.strip() if response.text else ""
    except Exception as e:
        logging.error(f"Gemini 錯誤：{e}")
        return ""


def analyze_resume(resume_text):
    """分析履歷內容並返回結果"""
    if not resume_text:
        raise ValueError("履歷內容為空，無法進行分析")
        
    try:
        # 構建分析提示
        skill_prompt = """
        請分析以下履歷內容的技能部分：
        {resume_text}
        請列出關鍵技能和專業能力。
        """
        
        suggestion_prompt = """
        請分析以下履歷內容並提供改進建議：
        {resume_text}
        請提供具體的改進建議。
        """
        
        evaluation_prompt = """
        請評估以下履歷內容（每項滿分100分）：
        {resume_text}
        請以JSON格式返回以下評分：
        {
            "技能匹配度": 分數,
            "工作經驗與成就": 分數,
            "履歷結構與可讀性": 分數,
            "個人特色": 分數,
            "學歷與成績": 分數,
            "證照與專業認證": 分數,
            "專案實作能力": 分數,
            "程式設計能力": 分數
        }
        """
        
        # 執行分析
        skills_d = ask_deepseek(skill_prompt.format(resume_text=resume_text))
        suggestions_d = ask_deepseek(suggestion_prompt.format(resume_text=resume_text))
        evaluation_d = ask_deepseek(evaluation_prompt.format(resume_text=resume_text))
        
        skills_g = ask_gemini(skill_prompt.format(resume_text=resume_text))
        suggestions_g = ask_gemini(suggestion_prompt.format(resume_text=resume_text))
        evaluation_g = ask_gemini(evaluation_prompt.format(resume_text=resume_text))
        
        skills_o = ask_openai(skill_prompt.format(resume_text=resume_text))
        suggestions_o = ask_openai(suggestion_prompt.format(resume_text=resume_text))
        evaluation_o = ask_openai(evaluation_prompt.format(resume_text=resume_text))
        
        # 處理評分數據
        from .TextUtils import extract_json_from_text, average_scores
        
        score_data_d = extract_json_from_text(evaluation_d)
        score_data_g = extract_json_from_text(evaluation_g)
        score_data_o = extract_json_from_text(evaluation_o)
        score_data = average_scores(score_data_d, score_data_g, score_data_o)
        
        return {
            "skills": {
                "deepseek": skills_d,
                "gemini": skills_g,
                "openai": skills_o
            },
            "suggestions": {
                "deepseek": suggestions_d,
                "gemini": suggestions_g,
                "openai": suggestions_o
            },
            "evaluations": {
                "deepseek": score_data_d,
                "gemini": score_data_g,
                "openai": score_data_o,
                "average": score_data
            }
        }
        
    except Exception as e:
        logging.error(f"分析過程發生錯誤: {str(e)}")
        raise
