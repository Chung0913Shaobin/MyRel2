# services/word_exporter.py

import os
from docx import Document
from docx.shared import Inches
import logging

def save_analysis_to_word(text, filepath):
    try:
        doc = Document()
        doc.add_heading("履歷分析結果", 0)

        # 加入文字分析建議
        for line in text.strip().split("\n"):
            doc.add_paragraph(line)

        # 插入 radar 圖
        charts = [
            ("summary", "統整分數"),
            ("deepseek", "DeepSeek 分析"),
            ("gemini", "Gemini 分析"),
            ("openai", "OpenAI 分析")
        ]

        for name, title in charts:
            img_path = os.path.join(os.path.dirname(filepath), f"radar_{name}.png")
            if os.path.exists(img_path):
                doc.add_page_break()
                doc.add_heading(title, level=1)
                doc.add_picture(img_path, width=Inches(5))
            else:
                logging.warning(f"⚠️ 找不到圖片 {img_path}，略過插入")

        doc.save(filepath)
        logging.info(f"✅ Word 檔案儲存完成：{filepath}")
        return filepath
    except Exception as e:
        logging.error(f"❌ Word 匯出失敗：{e}")
        return None
