import os
from werkzeug.utils import secure_filename
from PyPDF2 import PdfReader
from docx import Document
import logging

def save_file(file, upload_folder):
    filename = secure_filename(file.filename)
    file_ext = filename.rsplit(".", 1)[-1].lower()
    filepath = os.path.join(upload_folder, filename)
    file.save(filepath)
    return filepath, file_ext

def extract_text(filepath, extension):
    try:
        if extension == "pdf":
            reader = PdfReader(filepath)
            return "".join([page.extract_text() for page in reader.pages if page.extract_text()])
        elif extension == "docx":
            doc = Document(filepath)
            return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
        else:
            return ""
    except Exception as e:
        logging.error(f"檔案內容提取失敗：{e}")
        return ""
