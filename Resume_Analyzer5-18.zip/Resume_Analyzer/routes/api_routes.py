from flask import Blueprint, request, jsonify, current_app

api_routes = Blueprint('api', __name__)

@api_routes.route('/analyze_resume', methods=['POST'])  # 移除前綴/api
def analyze_resume():
    data = request.get_json()
    if not data or "image" not in data or "name" not in data:
        return "缺少圖像資料", 400

    try:
        image_base64 = data["image"].split(",")[1]
        image_bytes = base64.b64decode(image_base64)

        filename = f"radar_{data['name']}.png"
        chart_path = os.path.join(current_app.config["OUTPUT_FOLDER"], filename)

        with open(chart_path, "wb") as f:
            f.write(image_bytes)

        return "ok"
    except Exception as e:
        return f"處理圖像失敗：{str(e)}", 500
