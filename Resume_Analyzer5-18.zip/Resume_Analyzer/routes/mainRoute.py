from flask import Blueprint, request, render_template, current_app
import os
import logging
import json
from werkzeug.utils import secure_filename

from services.FileUtils import extract_text, save_file
from services.aiClients import ask_openai, ask_deepseek, ask_gemini
from services.TextUtils import clean_ai_output, extract_json_from_text, average_scores
from services.Word_Exporter import save_analysis_to_word

main_routes = Blueprint('main', __name__)

@main_routes.route('/')
def root():
    return render_template('menu.html')

@main_routes.route('/menu.html')
def index():
    return render_template('menu.html')

@main_routes.route('/resume_analysis.html')
def resume_analysis():
    return render_template('resume_analysis.html')

@main_routes.route('/analysis_result.html')
def analysis_result():
    return render_template('analysis_result.html')

@main_routes.route('/learning_resources.html')
def learning_resources():
    return render_template('learning_resources.html')

@main_routes.route('/profile.html')
def profile():
    return render_template('profile.html')

@main_routes.route('/company_matching.html')
def company_matching():
    return render_template('company_matching.html')


@main_routes.route('/upload', methods=['POST'])
def upload_file():
    if "file" not in request.files:
        return "未選擇檔案"
    file = request.files["file"]
    if file.filename == "":
        return "未選擇檔案"

    filename = secure_filename(file.filename)
    file_ext = filename.rsplit(".", 1)[1].lower()
    if file_ext not in ["pdf", "docx"]:
        return "不支援的檔案格式"

    filepath = os.path.join(current_app.config["UPLOAD_FOLDER"], filename)
    file.save(filepath)

    resume_text = extract_text(filepath, file_ext)
    if not resume_text.strip():
        return "履歷內容為空或無法解析"

    skill_prompt = f"""
    以下是我的履歷內容。請提取我具備的技能，並根據技能的特性進行分類（如編程語言、框架與工具、數據分析等）。
    請忽略文中提到的不熟悉或不擅長的技能，只列出明確提到具備或熟練的技能。
    輸出格式如下：

    分類名稱1：技能1, 技能2, 技能3

    分類名稱2：技能4, 技能5

    分類名稱3：技能6, 技能7
    ...

    履歷內容：
    {resume_text}
    """

    suggestion_prompt = f"""
    請根據以下履歷內容，分析並提供提升履歷質量的具體建議。

    履歷內容：
    {resume_text}

    請針對以下方面提出建議：
    - 段落結構
    - 資訊完整性
    - 技能表達
    - 專業用詞
    - 排版設計
    - 個人形象塑造

    請將建議整理為三個重點，每點建議控制在 50 字內，簡明扼要地提供具體改進方向。

    履歷優化建議：
    1. [建議 1]
    2. [建議 2]
    3. [建議 3]
    """
    
    evaluation_prompt = f"""
    你是一位專業的職涯顧問，請根據以下履歷進行分析與評分，並提供具體建議與推薦職缺。

    請嚴格依據履歷中實際出現的內容進行分析，評估履歷在以下 8 個面向的表現，每個面向滿分為 100 分，並以整數表示，最後總分為各面向平均值。

    回傳格式請包含：
    1. 分數（JSON 格式）
    2. 推薦職缺（3 個）
    3. 技能與關鍵字優化建議（條列式）

    請回傳如下格式(範例數據皆為模擬格式 請依照實際分析數據畫出圖形)：
    ---
    建議：
    [履歷的優劣勢建議]

    JSON 評分：
    {{
    "技能匹配度": **,
    "工作經驗與成就": **,
    "履歷結構與可讀性": **,
    "個人特色": **,
    "學歷與成績": **,
    "證照與專業認證": **,
    "專案實作能力": **,
    "程式設計能力": **
    }}

    推薦職缺：
    1. [職缺名稱]
    2. [職缺名稱]
    3. [職缺名稱]

    技能與關鍵字優化建議：
    - 建議補充技能：
    - [技能名稱]: [原因或對應職缺]
    - 建議加入關鍵字：
    - [關鍵字]: [能提升履歷吸引力的理由]

    履歷內容如下：
    {resume_text}
    """

    # --- 呼叫三組 AI ---
    skills_d = ask_deepseek(skill_prompt)
    suggestions_d = ask_deepseek(suggestion_prompt)
    evaluation_d = ask_deepseek(evaluation_prompt)

    skills_g = ask_gemini(skill_prompt)
    suggestions_g = ask_gemini(suggestion_prompt)
    evaluation_g = ask_gemini(evaluation_prompt)

    skills_o = ask_openai(skill_prompt)
    suggestions_o = ask_openai(suggestion_prompt)
    evaluation_o = ask_openai(evaluation_prompt)

    # --- 整合分析 prompt（新版）---
    final_prompt = f"""以下是三個 AI 模型對履歷的分析結果，請統整成最佳建議，並按照以下格式輸出：

    技能分類：
    [請列出並分類所有技能，每個分類獨立成段]

    履歷優化建議：
    [請列出 3-5 點具體改進建議]

    優劣勢分析：
    [請分析履歷的優點和需要改進之處]

    推薦職缺：
    [請列出 3 個最適合的職位推薦]

    請確保每個段落之間都有明確的分隔（使用兩個換行符），並使用清晰的標題標示每個部分。
    """
    
    def parse_evaluation_result(text):
        sections = {
            'skills_summary': '',
            'optimization_suggestions': '',
            'strengths_weaknesses': '',
            'job_recommendations': ''
        }
        
        # 解析技能分類
        if '技能分類：' in text:
            skills_start = text.find('技能分類：')
            skills_end = text.find('履歷優化建議：', skills_start) if '履歷優化建議：' in text else text.find('\n\n', skills_start)
            if skills_end == -1:
                skills_end = len(text)
            sections['skills_summary'] = text[skills_start:skills_end].strip()
        
        # 解析履歷建議
        if '履歷優化建議：' in text:
            suggestions_start = text.find('履歷優化建議：')
            suggestions_end = text.find('優劣勢分析：', suggestions_start) if '優劣勢分析：' in text else text.find('\n\n', suggestions_start)
            if suggestions_end == -1:
                suggestions_end = len(text)
            sections['optimization_suggestions'] = text[suggestions_start:suggestions_end].strip()
        
        # 解析優劣勢
        if '優劣勢分析：' in text:
            strengths_start = text.find('優劣勢分析：')
            strengths_end = text.find('推薦職缺：', strengths_start) if '推薦職缺：' in text else text.find('\n\n', strengths_start)
            if strengths_end == -1:
                strengths_end = len(text)
            sections['strengths_weaknesses'] = text[strengths_start:strengths_end].strip()
        
        # 解析推薦職缺
        if '推薦職缺：' in text:
            jobs_start = text.find('推薦職缺：')
            sections['job_recommendations'] = text[jobs_start:].strip()
        
        return sections
    
    # 處理分析結果
    final_result = ask_deepseek(final_prompt)
    cleaned_result = clean_ai_output(final_result)
    parsed_results = parse_evaluation_result(cleaned_result)
    
    # 計算評分
    score_data_d = extract_json_from_text(evaluation_d)
    score_data_g = extract_json_from_text(evaluation_g)
    score_data_o = extract_json_from_text(evaluation_o)
    score_data = average_scores(score_data_d, score_data_g, score_data_o)
    
    # 定義固定順序的標籤
    ordered_labels = [
        "技能匹配度",
        "工作經驗與成就",
        "履歷結構與可讀性",
        "個人特色",
        "學歷與成績",
        "證照與專業認證",
        "專案實作能力",
        "程式設計能力"
    ]
    
    # 按照固定順序獲取分數
    ordered_scores = [score_data[label] for label in ordered_labels]
    
    # 儲存結果
    output_folder = current_app.config["OUTPUT_FOLDER"]
    with open(os.path.join(output_folder, "result.txt"), "w", encoding="utf-8") as f:
        f.write(cleaned_result)
    
    # 回傳模板並傳遞分類後的資料
    return render_template("analysis_result.html",
        skills_summary=parsed_results['skills_summary'],
        optimization_suggestions=parsed_results['optimization_suggestions'],
        strengths_weaknesses=parsed_results['strengths_weaknesses'],
        job_recommendations=parsed_results['job_recommendations'],
        score_data=ordered_scores
    )

