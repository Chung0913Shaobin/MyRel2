import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_FOLDER = os.path.join(BASE_DIR, 'templates')  # 明確指定模板路徑
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "uploads")
OUTPUT_FOLDER = os.path.join(os.path.dirname(__file__), "static", "output")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

SECRET_KEY = "this_is_a_test_key_for_dev_123"

DEEPSEEK_API_KEY = "sk-c17852df776c481eaf9c7d7e7951b498"
GEMINI_API_KEY = "AIzaSyB2AsIs5YNb5wF_wpZ2xVySwv3mZ5pRF5s"
OPENAI_API_KEY = "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"

URL = "https://api.deepseek.com/v1/chat/completions"
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent"
