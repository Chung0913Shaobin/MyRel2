// 背景效果
document.addEventListener('mousemove', (e) => {
    const x = e.clientX / window.innerWidth;
    const y = e.clientY / window.innerHeight;
    
    document.querySelector('.bg-pattern').style.backgroundImage = `
        radial-gradient(circle at ${x * 100}% ${y * 100}%, rgba(56, 189, 248, 0.15), transparent 30%),
        radial-gradient(circle at ${(1-x) * 100}% ${(1-y) * 100}%, rgba(14, 165, 233, 0.1), transparent 30%)
    `;
});