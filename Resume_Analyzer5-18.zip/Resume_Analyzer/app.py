from flask import Flask, render_template, request, jsonify
from config import SECRET_KEY, UPLOAD_FOLDER, OUTPUT_FOLDER
import json
from werkzeug.utils import secure_filename
import logging
import os

from routes.mainRoute import main_routes
from routes.api_routes import api_routes

def create_app():
    app = Flask(__name__, 
               template_folder='templates',  # 新增模板目錄設定
               static_folder='static')       # 新增靜態文件目錄
    app.secret_key = SECRET_KEY
    app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
    app.config["OUTPUT_FOLDER"] = OUTPUT_FOLDER

    # 確保藍圖正確註冊
    app.register_blueprint(main_routes)
    app.register_blueprint(api_routes, url_prefix='/api')  # 添加 url_prefix

    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(message)s")

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
